<?php 
class Persegipanjang {
	public $panjang;
	public $lebar;
		
		
		function luas($l){
	$l=$panjang*$lebar;
	echo $l;
}	
		function keliling($k)
		{
			$k=2*($panjang+$lebar);
			echo $k;
		}
}

?>

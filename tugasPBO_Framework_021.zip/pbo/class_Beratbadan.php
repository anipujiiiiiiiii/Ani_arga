<?php
class Beratbadan
{
	public $tb;
	public $bb;

function beratideal($bi)
			{
			$bi=$tb-110;
	if ($bi=$bb) {
			echo "Berat anda ideal";
		}else {
		echo "berat anda tidak ideal";
}
function beratnormal($bn)
{
	$bn=$tb-100;
	if($bn=$bb){
		echo "berat anda normal";
	
	}else {
		echo "berat anda tidak normal";
		
	}
}
}
}
?>
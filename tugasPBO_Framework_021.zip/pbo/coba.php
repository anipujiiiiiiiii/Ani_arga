<?php
include "class_Beratbadan.php";
$Beratbadan_wow= new Beratbadan();

$Beratbadan_wow->tb = 170;
$Beratbadan_wow->bb = 69;
echo $Beratbadan_wow->beratideal($bi); 


?>
<?php
include "class_Persegipanjang.php";

$Persegipanjang_jos= new Persegipanjang();

$Persegipanjang_jos->panjang =12;
$Persegipanjang_jos->lebar =13;
echo $Persegipanjang_jos->luas ($l);
echo $Persegipanjang_jos->keliling ($k);
?>

